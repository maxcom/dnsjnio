Notes for dnsjava-nio version @VERSION_STRING@

dnsjava-nio is an extension module for dnsjava that
uses the NIO library (java.nio) to handle the I/O.
The NonblockingResolver class is used instead of
SimpleResolver.

Each instance of NonblockingResolver will, where
possible, route all queries over a single port.
If a query is sent which has the same header ID
as a query currently in use on the single port,
then a new port will be used for that query.

The existing ResolverListener interface is still
available. This interface requires each response
to be handled by a new server thread.

However, a new interface, using a ResponseQueue,
is also supported. To use this interface, the
caller must pass in a ResponseQueue to the
sendAsync() call. When the response is available,
it will be added to the blocking queue. The caller
must simply remove the response from the queue,
and process it in its own thread.

This functionality allows DNS queries to be run
in a single thread, and be sent over a single port.

