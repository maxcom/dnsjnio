package uk.nominet.dnsjnio;

/**
 * Callback interface for Timer
 */
public interface TimerListener {
    public void timedOut(QueryData qData);
}
