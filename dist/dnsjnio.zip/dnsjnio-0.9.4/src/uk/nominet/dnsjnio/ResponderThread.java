package uk.nominet.dnsjnio;

import org.xbill.DNS.Message;
import org.xbill.DNS.ResolverListener;

/**
 * This class is used when a NonblockingResolver is used with
 * the old sendAsync(...ResolverListener) method.
 */
public class ResponderThread extends Thread {
    Object id;
    Message response;
    ResolverListener listener;
    Exception e;
    public ResponderThread(ResolverListener listener, Object id, Message response) {
        this.listener = listener;
        this.id = id;
        this.response = response;
    }
    public ResponderThread(ResolverListener listener, Object id, Exception e) {
        this.listener = listener;
        this.id = id;
        this.e = e;
    }
    public void run() {
        if (response != null) {
            listener.receiveMessage(id, response);
        }
        else {
            listener.handleException(id, e);
        }
    }
}
