package uk.nominet.dnsjnio;

import junit.framework.TestCase;

/**
 * Exercise the ExtendedNonblockingResolver a little
 */
public class ExtendedResolverTest extends TestCase {
    public void testExtendedResolver() {
        // @todo!!
    }
}
