package uk.nominet.dns;

import junit.framework.TestCase;
import org.xbill.DNS.*;

/**
 *
 * Test that we can connect to a real server...
 */
public class RemoteServerTest extends TestCase {
    final static String SERVER = "65.201.175.34";
    public RemoteServerTest(String arg0) {
        super(arg0);
    }

    public void testRemoteServer() throws Exception {
        Resolver resolver = new NonblockingResolver(SERVER);
        resolver.setPort(53);

        Name name = Name.fromString("example.net", Name.root);
        Record question = Record.newRecord(name, Type.A, DClass.ANY);
        Message query = Message.newQuery(question);
        Message response = resolver.send(query);
        assertTrue(response.getRcode() == Rcode.NOERROR);
    }

    public void testRemoteServerTcp() throws Exception {
        Resolver resolver = new NonblockingResolver(SERVER);
        resolver.setTCP(true);

        Name name = Name.fromString("example.com", Name.root);
        Record question = Record.newRecord(name, Type.A, DClass.ANY);
        Message query = Message.newQuery(question);
        Message response = resolver.send(query);
        assertTrue(response.getRcode() == Rcode.NOERROR);
    }

}
