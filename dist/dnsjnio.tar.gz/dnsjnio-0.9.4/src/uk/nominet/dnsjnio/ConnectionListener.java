package uk.nominet.dnsjnio;

/**
 * Interface specifying callbacks from Connection.
 */
public interface ConnectionListener extends java.util.EventListener {
    public void readyToSend(Connection connection);
    public void closed(Connection connection);
    public void dataAvailable(byte[] data, Connection connection);
    public int getPort();
}
 
