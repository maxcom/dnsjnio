package uk.nominet.dnsjnio;

import java.util.LinkedList;

/**
 * This class implements a simple queue.
 * It blocks threads wishing to remove an object from the queue
 * until an object is available.
 */
public class ResponseQueue extends LinkedList
{
	private int waitingThreads = 0;
                                                                                        
    /**
     * This method is called internally to add a new Response to the queue.
     * @param response the new Response
     */
    public synchronized void insert(Response response)
	{
		addLast(response);
		notify();
	}

	public synchronized Response remove()
	{
		if ( isEmpty() ) {
			try	{ waitingThreads++; wait();}
			catch (InterruptedException e)	{Thread.interrupted();}
			waitingThreads--;
		}
		return (Response)removeFirst();
	}

	public boolean isEmpty() {
		return 	(size() - waitingThreads <= 0);
	}
}
