package uk.nominet.dnsjnio;

import java.nio.channels.*;
import java.io.IOException;
import java.util.*;

/**
 * This class controls the I/O using the java.nio package.
 * A select thread is created, which runs the select loop
 * forever.
 * A queue of invocations is kept for the thread, and an
 * outgoing queue is also instantiated.
 * One DnsController services all resolvers
 */
public class DnsController {
    private static DnsController INSTANCE = new DnsController();
    private static List invocations;
    private static Selector selector;
    private static Thread selectThread;

    private DnsController() {
        initialise();
    }

    public static DnsController getInstance() {
        return INSTANCE;
    }

    public static Selector getSelector() {
        return selector;
    }

    private static void initialise() {
        invocations = new LinkedList();
        try {
            selector = Selector.open();
        } catch(IOException ie) {
            // log error?
            System.out.println("Error - can't open selector\r\n" + ie);
        }
        selectThread = new Thread("DnsSelect") {
            public void run() {
                selectLoop();
            }
        };
        selectThread.start();
    }

    private static void selectLoop() {
        Runnable task;
        while (true) {
            do {
                task = null;
                synchronized (invocations) {
                    if (invocations.size() > 0) {
                        task = (Runnable)(invocations.get(0));
                        invocations.remove(0);
                        task.run();
                    }
                }
            } while(task != null);

            try {
                selector.select();
            } catch(Exception e) {
                int deleteMe = 0;
            }

            // process any selected keys
            Set selectedKeys = selector.selectedKeys();
            Iterator it = selectedKeys.iterator();
            while(it.hasNext()) {
                SelectionKey key = (SelectionKey)(it.next());
                Connection conn = (Connection)key.attachment();
                int kro = key.readyOps();
                if((kro & SelectionKey.OP_READ) == SelectionKey.OP_READ) {
                    conn.doRead();
                }
                if((kro & SelectionKey.OP_WRITE) == SelectionKey.OP_WRITE) {
                    conn.doWrite();
                }
                if((kro & SelectionKey.OP_CONNECT) == SelectionKey.OP_CONNECT) {
                    conn.doConnect();
                }
                it.remove();
            }
        }
    }

    public static void invoke(Runnable task) {
        synchronized (invocations) {
            invocations.add(invocations.size(), task);
        }
        selector.wakeup();
    }

    public static boolean isSelectThread() {
        return Thread.currentThread() == selectThread;
    }
}
