package uk.nominet.dnsjnio;

/**
 */
public class ListenerAndData {
    TimerListener listener;
    QueryData qData;

    public TimerListener getListener() {
        return listener;
    }

    public void setListener(TimerListener listener) {
        this.listener = listener;
    }

    public QueryData getqData() {
        return qData;
    }

    public void setqData(QueryData qData) {
        this.qData = qData;
    }
}
