package uk.nominet.dnsjnio;

/* The Version.java class is automatically generated from Version.java.ant,
        and should not be modified */        
public class Version
{
  public static String VERSION = "0.9.4";
}
